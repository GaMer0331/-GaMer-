### 𝕍𝕚𝕕𝕖𝕠 ℂ𝕆𝕄ℙℝ𝔼𝕊𝕊𝕆ℝ 𝔹𝕆𝕋

### ᴍᴜʟᴛɪғᴜɴᴄᴛɪᴏɴ ǫᴜᴀʟɪᴛʏ ᴄᴏᴍᴘʀᴇssᴏʀ


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?button-url=https%3A%2F%2Fgithub.com%2F1Danish-00%2FCompressorBotp&amp;template=https%3A%2F%2Fgithub.com%2F1Danish-00%2FCompressorBot)

### A Telegram Video CompressorBot

- it compress videos with negligible Quality change.
- u can generate sample Compressed videos nd screenshots too.
- u can set custom video name nd Thumbnail.
- u can get logs videos to a channel too.
- Coz of its Quality encode It takes little time to Compress.
- For now i set it for maximum 5 Processes at a time.
- Its Running Without Db so Block /ban /Broadcast Feature is currently Not available.
